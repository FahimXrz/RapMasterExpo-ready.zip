import React from 'react';
import { motion } from 'motion/react';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { GameState } from '../App';
import { TrendingUp, Users, DollarSign, Music, Star, Zap, Trophy, Play, Headphones } from 'lucide-react';

interface WeeklyResultsProps {
  gameState: GameState;
  onClose: () => void;
}

export function WeeklyResults({ gameState, onClose }: WeeklyResultsProps) {
  // Calculate this week's performance
  const thisWeekTracks = gameState.tracks.filter(track => 
    gameState.week - track.week <= 1
  );
  
  const weeklyStats = gameState.tracks.reduce((acc, track) => {
    // Estimate weekly growth (this would be calculated differently in a real scenario)
    const trackAge = gameState.week - track.week;
    if (trackAge <= 8) { // Only count active tracks
      acc.streams += track.platforms.rpotify.enabled ? Math.floor(track.platforms.rpotify.streams * 0.1) : 0;
      acc.views += track.platforms.raptube.enabled ? Math.floor(track.platforms.raptube.views * 0.08) : 0;
      acc.riktokViews += track.platforms.riktok.enabled ? Math.floor(track.platforms.riktok.views * 0.12) : 0;
      if (track.platforms.riktok.viral && trackAge === 0) {
        acc.viralMoments++;
      }
    }
    return acc;
  }, { streams: 0, views: 0, riktokViews: 0, viralMoments: 0 });

  const weeklyRevenue = (weeklyStats.streams * 0.30) + (weeklyStats.views * 0.15) + (weeklyStats.viralMoments * 500);
  const fanGrowth = Math.floor((weeklyStats.streams * 0.001) + (weeklyStats.views * 0.0005) + (weeklyStats.riktokViews * 0.002)) + 50;

  const achievements = [];
  if (thisWeekTracks.length > 0) achievements.push('🎵 Released New Music');
  if (weeklyStats.viralMoments > 0) achievements.push('🔥 Went Viral on Riktok');
  if (weeklyRevenue > 1000) achievements.push('💰 High Revenue Week');
  if (fanGrowth > 200) achievements.push('📈 Major Fan Growth');
  if (gameState.tracks.length >= 5) achievements.push('🎤 Prolific Artist');

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900 p-4 flex items-center justify-center">
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.5 }}
        className="w-full max-w-md"
      >
        <Card className="bg-white/10 border-white/20 backdrop-blur-lg p-6">
          {/* Header */}
          <div className="text-center mb-6">
            <div className="w-16 h-16 bg-gradient-to-br from-pink-500 to-purple-600 rounded-full mx-auto mb-3 flex items-center justify-center">
              <Trophy className="w-8 h-8 text-white" />
            </div>
            <h2 className="text-white font-bold text-xl">Week {gameState.week} Results</h2>
            <p className="text-purple-200 text-sm">Your music career update</p>
          </div>

          {/* New Releases This Week */}
          {thisWeekTracks.length > 0 && (
            <Card className="bg-gradient-to-r from-purple-500/20 to-pink-500/20 border-purple-500/30 p-4 mb-4">
              <h3 className="text-white font-bold mb-2 flex items-center">
                <Music className="w-4 h-4 mr-2" />
                New Releases
              </h3>
              {thisWeekTracks.map(track => (
                <div key={track.id} className="mb-2 last:mb-0">
                  <p className="text-white font-medium">{track.title}</p>
                  <div className="flex space-x-2 mt-1">
                    {track.platforms.rpotify.enabled && (
                      <Badge className="bg-green-500/20 text-green-300 text-xs">📱 Rpotify</Badge>
                    )}
                    {track.platforms.raptube.enabled && (
                      <Badge className="bg-red-500/20 text-red-300 text-xs">📺 RapTube</Badge>
                    )}
                    {track.platforms.riktok.enabled && (
                      <Badge className="bg-purple-500/20 text-purple-300 text-xs">🎵 Riktok</Badge>
                    )}
                  </div>
                  {track.platforms.riktok.viral && (
                    <div className="mt-2 p-2 bg-yellow-500/20 border border-yellow-500/30 rounded">
                      <p className="text-yellow-300 text-xs">🔥 WENT VIRAL ON RIKTOK!</p>
                    </div>
                  )}
                </div>
              ))}
            </Card>
          )}

          {/* Platform Performance */}
          <div className="grid grid-cols-3 gap-3 mb-4">
            <Card className="bg-green-500/20 border-green-500/30 p-3 text-center">
              <Headphones className="w-5 h-5 text-green-400 mx-auto mb-1" />
              <p className="text-green-200 text-xs">Rpotify Streams</p>
              <p className="text-white font-bold">+{weeklyStats.streams.toLocaleString()}</p>
            </Card>
            <Card className="bg-red-500/20 border-red-500/30 p-3 text-center">
              <Play className="w-5 h-5 text-red-400 mx-auto mb-1" />
              <p className="text-red-200 text-xs">RapTube Views</p>
              <p className="text-white font-bold">+{weeklyStats.views.toLocaleString()}</p>
            </Card>
            <Card className="bg-purple-500/20 border-purple-500/30 p-3 text-center">
              <TrendingUp className="w-5 h-5 text-purple-400 mx-auto mb-1" />
              <p className="text-purple-200 text-xs">Riktok Views</p>
              <p className="text-white font-bold">+{weeklyStats.riktokViews.toLocaleString()}</p>
            </Card>
          </div>

          {/* Main Stats */}
          <div className="grid grid-cols-2 gap-4 mb-4">
            <Card className="bg-green-500/20 border-green-500/30 p-4">
              <div className="flex items-center space-x-3">
                <DollarSign className="w-6 h-6 text-green-400" />
                <div>
                  <p className="text-green-200 text-sm">Revenue</p>
                  <p className="text-white font-bold">+${weeklyRevenue.toLocaleString()}</p>
                </div>
              </div>
            </Card>
            <Card className="bg-blue-500/20 border-blue-500/30 p-4">
              <div className="flex items-center space-x-3">
                <Users className="w-6 h-6 text-blue-400" />
                <div>
                  <p className="text-blue-200 text-sm">New Fans</p>
                  <p className="text-white font-bold">+{fanGrowth.toLocaleString()}</p>
                </div>
              </div>
            </Card>
          </div>

          {/* Viral Moments */}
          {weeklyStats.viralMoments > 0 && (
            <Card className="bg-yellow-500/20 border-yellow-500/30 p-4 mb-4">
              <h3 className="text-yellow-200 font-bold mb-2 flex items-center">
                <Zap className="w-4 h-4 mr-2" />
                Viral Moments This Week
              </h3>
              <p className="text-yellow-300 text-sm">
                🔥 {weeklyStats.viralMoments} track{weeklyStats.viralMoments > 1 ? 's' : ''} went viral on Riktok!
              </p>
              <p className="text-yellow-300 text-xs mt-1">
                Bonus revenue: +${(weeklyStats.viralMoments * 500).toLocaleString()}
              </p>
            </Card>
          )}

          {/* Achievements */}
          {achievements.length > 0 && (
            <Card className="bg-white/10 border-white/20 p-4 mb-4">
              <h3 className="text-white font-bold mb-2 flex items-center">
                <Star className="w-4 h-4 mr-2" />
                Achievements
              </h3>
              <div className="space-y-1">
                {achievements.map((achievement, index) => (
                  <p key={index} className="text-purple-200 text-sm">{achievement}</p>
                ))}
              </div>
            </Card>
          )}

          {/* Career Progress */}
          <Card className="bg-white/10 border-white/20 p-4 mb-6">
            <h3 className="text-white font-bold mb-3">Career Progress</h3>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-purple-200">Total Tracks:</span>
                <span className="text-white">{gameState.tracks.length}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-purple-200">Total Fans:</span>
                <span className="text-white">{gameState.fans.toLocaleString()}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-purple-200">Fame Level:</span>
                <span className="text-white">{Math.floor(gameState.fame)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-purple-200">Studio Level:</span>
                <span className="text-white">
                  {gameState.studioLevel === 1 ? 'Basic' : 
                   gameState.studioLevel === 2 ? 'Premium' : 'Pro'}
                </span>
              </div>
            </div>
          </Card>

          {/* Continue Button */}
          <Button
            onClick={onClose}
            className="w-full bg-gradient-to-r from-pink-500 to-purple-600 hover:from-pink-600 hover:to-purple-700 text-white font-semibold py-3 rounded-xl"
          >
            Continue Journey
          </Button>
        </Card>
      </motion.div>
    </div>
  );
}