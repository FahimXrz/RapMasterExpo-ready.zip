import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { Label } from './ui/label';
import { GameState, Track } from '../App';
import { 
  Music, 
  Play, 
  Mic, 
  Headphones, 
  Users, 
  TrendingUp, 
  Eye, 
  Heart,
  ArrowRight,
  ArrowLeft,
  CheckCircle,
  Star,
  Zap,
  DollarSign
} from 'lucide-react';

interface MusicCreationProps {
  gameState: GameState;
  setGameState: React.Dispatch<React.SetStateAction<GameState>>;
}

type CreationStep = 'studio' | 'type' | 'lyrics' | 'beat' | 'record' | 'platforms' | 'preview' | 'release';

interface TrackCreation {
  title: string;
  type: 'single';
  genre: string;
  beat: string;
  platforms: {
    rpotify: boolean;
    raptube: boolean;
    riktok: boolean;
  };
  quality: number;
  estimatedSuccess: number;
  energyCost: number;
  moneyCost: number;
}

export function MusicCreation({ gameState, setGameState }: MusicCreationProps) {
  const [currentStep, setCurrentStep] = useState<CreationStep>('studio');
  const [trackData, setTrackData] = useState<TrackCreation>({
    title: '',
    type: 'single',
    genre: '',
    beat: '',
    platforms: {
      rpotify: false,
      raptube: false,
      riktok: false
    },
    quality: 0,
    estimatedSuccess: 0,
    energyCost: 20,
    moneyCost: 100
  });

  const genres = [
    { id: 'hip-hop', name: 'Hip-Hop', audience: 'Mainstream', emoji: '🎤' },
    { id: 'trap', name: 'Trap', audience: 'Young Adults', emoji: '🔥' },
    { id: 'drill', name: 'Drill', audience: 'Street Culture', emoji: '💀' },
    { id: 'lo-fi', name: 'Lo-Fi Hip-Hop', audience: 'Chill Listeners', emoji: '🌙' },
    { id: 'pop-rap', name: 'Pop Rap', audience: 'Radio Friendly', emoji: '📻' },
    { id: 'boom-bap', name: 'Boom Bap', audience: 'Old School Fans', emoji: '👴' }
  ];

  const beats = [
    { id: 'hard', name: 'Hard Hitting', vibe: 'Aggressive', emoji: '⚡' },
    { id: 'melodic', name: 'Melodic', vibe: 'Emotional', emoji: '🎹' },
    { id: 'minimal', name: 'Minimal', vibe: 'Simple', emoji: '🔘' },
    { id: 'bouncy', name: 'Bouncy', vibe: 'Catchy', emoji: '🏀' },
    { id: 'atmospheric', name: 'Atmospheric', vibe: 'Dreamy', emoji: '☁️' },
    { id: 'classic', name: 'Classic', vibe: 'Timeless', emoji: '🏛️' }
  ];

  const studioLevels = [
    { level: 1, name: 'Basic Studio', quality: 0.7, description: 'Home setup with basic equipment' },
    { level: 2, name: 'Premium Studio', quality: 0.85, description: 'Professional recording space' },
    { level: 3, name: 'Pro Studio', quality: 1.0, description: 'Industry-standard facilities' }
  ];

  const calculateSuccess = () => {
    const skills = gameState.skills;
    const studioQuality = studioLevels.find(s => s.level === gameState.studioLevel)?.quality || 0.7;
    const platformMultiplier = Object.values(trackData.platforms).filter(Boolean).length * 0.2 + 0.8;
    
    // Success Formula: (Rap × 0.4) + (Flow × 0.3) + (Charisma × 0.2) + (Studio × 0.1) + Random Viral Factor
    const baseSuccess = (
      (skills.rap * 0.4) + 
      (skills.flow * 0.3) + 
      (skills.charisma * 0.2) + 
      (studioQuality * 30 * 0.1)
    ) * platformMultiplier;
    
    const viralFactor = Math.random() * 20; // 0-20% viral bonus
    return Math.min(100, baseSuccess + viralFactor);
  };

  const calculateCosts = () => {
    const platformCount = Object.values(trackData.platforms).filter(Boolean).length;
    const energyCost = 20 + (platformCount * 10);
    const moneyCost = 100 + (platformCount * 50) + (gameState.studioLevel * 25);
    
    setTrackData(prev => ({ 
      ...prev, 
      energyCost, 
      moneyCost,
      estimatedSuccess: calculateSuccess()
    }));
  };

  React.useEffect(() => {
    calculateCosts();
  }, [trackData.platforms, trackData.genre, trackData.beat, gameState.skills, gameState.studioLevel]);

  const generateTitles = (baseTitle: string) => {
    return {
      rpotify: baseTitle,
      raptube: `${baseTitle} (Official Music Video)`,
      riktok: `${baseTitle} - Snippet`
    };
  };

  const createTrack = () => {
    if (!trackData.title.trim() || !trackData.genre || !trackData.beat) return;
    if (gameState.energy < trackData.energyCost || gameState.money < trackData.moneyCost) return;
    
    const titles = generateTitles(trackData.title);
    const viralFactor = Math.random() * 20;
    const quality = calculateSuccess();
    
    const newTrack: Track = {
      id: Date.now().toString(),
      title: trackData.title,
      genre: trackData.genre,
      beat: trackData.beat,
      week: gameState.week,
      platforms: {
        rpotify: {
          enabled: trackData.platforms.rpotify,
          streams: 0,
          title: titles.rpotify
        },
        raptube: {
          enabled: trackData.platforms.raptube,
          views: 0,
          title: titles.raptube
        },
        riktok: {
          enabled: trackData.platforms.riktok,
          views: 0,
          viral: false
        }
      },
      likes: 0,
      quality,
      viralFactor,
      peakWeek: gameState.week + Math.floor(Math.random() * 3) + 1,
      isDeclined: false
    };

    setGameState(prev => ({
      ...prev,
      tracks: [...prev.tracks, newTrack],
      energy: prev.energy - trackData.energyCost,
      money: prev.money - trackData.moneyCost
    }));

    // Reset form
    setTrackData({
      title: '',
      type: 'single',
      genre: '',
      beat: '',
      platforms: { rpotify: false, raptube: false, riktok: false },
      quality: 0,
      estimatedSuccess: 0,
      energyCost: 20,
      moneyCost: 100
    });
    setCurrentStep('studio');
  };

  const renderStepContent = () => {
    switch (currentStep) {
      case 'studio':
        return (
          <div className="space-y-6">
            <div className="text-center">
              <div className="w-20 h-20 bg-gradient-to-br from-purple-500 to-pink-500 rounded-full mx-auto mb-4 flex items-center justify-center shadow-lg">
                <Headphones className="w-10 h-10 text-white" />
              </div>
              <h3 className="text-white font-bold mb-2">Enter the Studio</h3>
              <p className="text-purple-200 text-sm">Ready to create your next masterpiece?</p>
            </div>

            <Card className="bg-white/10 border-white/20 backdrop-blur-sm p-4">
              <div className="flex items-center space-x-3 mb-3">
                <Star className="w-5 h-5 text-yellow-400" />
                <div>
                  <p className="text-white font-medium">{studioLevels[gameState.studioLevel - 1].name}</p>
                  <p className="text-purple-200 text-xs">{studioLevels[gameState.studioLevel - 1].description}</p>
                </div>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-purple-200 text-sm">Recording Quality</span>
                <Badge className="bg-purple-500/20 text-purple-300">
                  {Math.round(studioLevels[gameState.studioLevel - 1].quality * 100)}%
                </Badge>
              </div>
            </Card>

            <div className="grid grid-cols-3 gap-3 text-center text-sm">
              <div className="bg-white/10 rounded-xl p-3">
                <Mic className="w-6 h-6 text-pink-400 mx-auto mb-1" />
                <p className="text-white">Rap: {gameState.skills.rap}</p>
              </div>
              <div className="bg-white/10 rounded-xl p-3">
                <Music className="w-6 h-6 text-blue-400 mx-auto mb-1" />
                <p className="text-white">Flow: {gameState.skills.flow}</p>
              </div>
              <div className="bg-white/10 rounded-xl p-3">
                <Users className="w-6 h-6 text-green-400 mx-auto mb-1" />
                <p className="text-white">Charisma: {gameState.skills.charisma}</p>
              </div>
            </div>

            <Button
              onClick={() => setCurrentStep('type')}
              className="w-full bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 rounded-xl py-3"
            >
              <Play className="w-4 h-4 mr-2" />
              Start Recording Session
            </Button>
          </div>
        );

      case 'type':
        return (
          <div className="space-y-6">
            <div className="text-center">
              <h3 className="text-white font-bold mb-2">Choose Track Type</h3>
              <p className="text-purple-200 text-sm">What kind of track are you making?</p>
            </div>

            <Card className="bg-gradient-to-br from-purple-500/20 to-pink-500/20 border-purple-500/30 p-6 cursor-pointer hover:bg-purple-500/30 transition-all">
              <div className="text-center">
                <Music className="w-12 h-12 text-purple-300 mx-auto mb-3" />
                <h4 className="text-white font-bold">🎵 Single</h4>
                <p className="text-purple-200 text-sm mt-2">Create a standalone track for maximum impact</p>
                <Badge className="bg-purple-500/20 text-purple-300 mt-3">Available in Beta</Badge>
              </div>
            </Card>

            <div className="grid gap-3 opacity-50">
              <Card className="bg-white/10 border-white/20 p-4">
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 bg-orange-500/20 rounded-lg flex items-center justify-center">
                    <Music className="w-5 h-5 text-orange-400" />
                  </div>
                  <div className="flex-1">
                    <p className="text-white font-medium">🎼 Album</p>
                    <p className="text-purple-200 text-xs">Full album with multiple tracks</p>
                  </div>
                  <Badge className="bg-orange-500/20 text-orange-300">Full Version</Badge>
                </div>
              </Card>
              <Card className="bg-white/10 border-white/20 p-4">
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 bg-blue-500/20 rounded-lg flex items-center justify-center">
                    <Users className="w-5 h-5 text-blue-400" />
                  </div>
                  <div className="flex-1">
                    <p className="text-white font-medium">🤝 Collaboration</p>
                    <p className="text-purple-200 text-xs">Work with other artists</p>
                  </div>
                  <Badge className="bg-blue-500/20 text-blue-300">Full Version</Badge>
                </div>
              </Card>
            </div>

            <div className="flex space-x-3">
              <Button
                onClick={() => setCurrentStep('studio')}
                variant="outline"
                className="flex-1 border-white/20 text-white rounded-xl"
              >
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back
              </Button>
              <Button
                onClick={() => setCurrentStep('lyrics')}
                className="flex-1 bg-gradient-to-r from-purple-500 to-pink-500 rounded-xl"
              >
                Continue
                <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            </div>
          </div>
        );

      case 'lyrics':
        return (
          <div className="space-y-6">
            <div className="text-center">
              <h3 className="text-white font-bold mb-2">Write Your Lyrics</h3>
              <p className="text-purple-200 text-sm">Give your track a catchy title</p>
            </div>

            <div>
              <Label className="text-white mb-2 block">Track Title</Label>
              <Input
                type="text"
                value={trackData.title}
                onChange={(e) => setTrackData(prev => ({ ...prev, title: e.target.value }))}
                placeholder="Enter your track title (e.g., Broken)"
                className="bg-white/20 border-white/30 text-white placeholder-white/70 rounded-xl"
                maxLength={50}
              />
              <p className="text-purple-200 text-xs mt-1">This will auto-format for each platform</p>
            </div>

            {trackData.title && (
              <Card className="bg-white/10 border-white/20 p-4">
                <h4 className="text-white font-medium mb-3">Platform Titles Preview:</h4>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-green-300">📱 Rpotify:</span>
                    <span className="text-white">"{trackData.title}"</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-red-300">📺 RapTube:</span>
                    <span className="text-white">"{trackData.title} (Official Music Video)"</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-purple-300">🎵 Riktok:</span>
                    <span className="text-white">"{trackData.title} - Snippet"</span>
                  </div>
                </div>
              </Card>
            )}

            <Card className="bg-orange-500/20 border-orange-500/30 p-4">
              <h4 className="text-orange-200 font-medium mb-2">🎤 Lyric Styles (Beta Limited)</h4>
              <div className="grid grid-cols-3 gap-2 text-xs">
                <div className="bg-orange-500/20 rounded-lg p-2 text-center">
                  <p className="text-orange-300">🔥 Trap</p>
                  <p className="text-orange-200">Hard bars</p>
                </div>
                <div className="bg-orange-500/20 rounded-lg p-2 text-center">
                  <p className="text-orange-300">💭 Boom Bap</p>
                  <p className="text-orange-200">Lyrical</p>
                </div>
                <div className="bg-orange-500/20 rounded-lg p-2 text-center">
                  <p className="text-orange-300">⚡ Drill</p>
                  <p className="text-orange-200">Street</p>
                </div>
              </div>
              <p className="text-orange-300 text-xs mt-2">Full lyric editor coming in complete version</p>
            </Card>

            <div className="flex space-x-3">
              <Button
                onClick={() => setCurrentStep('type')}
                variant="outline"
                className="flex-1 border-white/20 text-white rounded-xl"
              >
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back
              </Button>
              <Button
                onClick={() => setCurrentStep('beat')}
                disabled={!trackData.title.trim()}
                className="flex-1 bg-gradient-to-r from-purple-500 to-pink-500 rounded-xl disabled:opacity-50"
              >
                Continue
                <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            </div>
          </div>
        );

      case 'beat':
        return (
          <div className="space-y-6">
            <div className="text-center">
              <h3 className="text-white font-bold mb-2">Pick Your Beat</h3>
              <p className="text-purple-200 text-sm">Choose genre and beat style</p>
            </div>

            <div>
              <Label className="text-white mb-3 block">Genre</Label>
              <div className="grid grid-cols-2 gap-3">
                {genres.map((genre) => (
                  <button
                    key={genre.id}
                    onClick={() => setTrackData(prev => ({ ...prev, genre: genre.id }))}
                    className={`p-3 rounded-xl border transition-all ${
                      trackData.genre === genre.id
                        ? 'bg-gradient-to-br from-purple-500/30 to-pink-500/30 border-purple-500'
                        : 'bg-white/10 border-white/20 hover:bg-white/20'
                    }`}
                  >
                    <div className="text-2xl mb-1">{genre.emoji}</div>
                    <p className="text-white text-sm font-medium">{genre.name}</p>
                    <p className="text-purple-200 text-xs">{genre.audience}</p>
                  </button>
                ))}
              </div>
            </div>

            {trackData.genre && (
              <div>
                <Label className="text-white mb-3 block">Beat Style</Label>
                <div className="grid grid-cols-2 gap-3">
                  {beats.map((beat) => (
                    <button
                      key={beat.id}
                      onClick={() => setTrackData(prev => ({ ...prev, beat: beat.id }))}
                      className={`p-3 rounded-xl border transition-all ${
                        trackData.beat === beat.id
                          ? 'bg-gradient-to-br from-blue-500/30 to-cyan-500/30 border-blue-500'
                          : 'bg-white/10 border-white/20 hover:bg-white/20'
                      }`}
                    >
                      <div className="text-2xl mb-1">{beat.emoji}</div>
                      <p className="text-white text-sm font-medium">{beat.name}</p>
                      <p className="text-blue-200 text-xs">{beat.vibe}</p>
                    </button>
                  ))}
                </div>
              </div>
            )}

            <div className="flex space-x-3">
              <Button
                onClick={() => setCurrentStep('lyrics')}
                variant="outline"
                className="flex-1 border-white/20 text-white rounded-xl"
              >
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back
              </Button>
              <Button
                onClick={() => setCurrentStep('record')}
                disabled={!trackData.genre || !trackData.beat}
                className="flex-1 bg-gradient-to-r from-purple-500 to-pink-500 rounded-xl disabled:opacity-50"
              >
                Continue
                <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            </div>
          </div>
        );

      case 'record':
        return (
          <div className="space-y-6">
            <div className="text-center">
              <div className="w-20 h-20 bg-gradient-to-br from-red-500 to-pink-500 rounded-full mx-auto mb-4 flex items-center justify-center shadow-lg animate-pulse">
                <Mic className="w-10 h-10 text-white" />
              </div>
              <h3 className="text-white font-bold mb-2">Recording Quality</h3>
              <p className="text-purple-200 text-sm">Your skills determine the final result</p>
            </div>

            <Card className="bg-white/10 border-white/20 p-4">
              <h4 className="text-white font-medium mb-3">Track Quality Factors:</h4>
              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-purple-200 text-sm">🎤 Rap Skill Influence</span>
                  <Badge className="bg-pink-500/20 text-pink-300">40%</Badge>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-purple-200 text-sm">🎼 Flow Skill Influence</span>
                  <Badge className="bg-blue-500/20 text-blue-300">30%</Badge>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-purple-200 text-sm">🎭 Charisma Influence</span>
                  <Badge className="bg-green-500/20 text-green-300">20%</Badge>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-purple-200 text-sm">🎧 Studio Quality</span>
                  <Badge className="bg-yellow-500/20 text-yellow-300">10%</Badge>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-purple-200 text-sm">🎲 Viral Factor</span>
                  <Badge className="bg-purple-500/20 text-purple-300">0-20%</Badge>
                </div>
              </div>
            </Card>

            <Card className="bg-gradient-to-r from-purple-500/20 to-pink-500/20 border-purple-500/30 p-4">
              <div className="text-center">
                <h4 className="text-white font-bold mb-2">Recording Complete!</h4>
                <p className="text-purple-200 text-sm">Ready to choose release platforms</p>
                <div className="w-full bg-purple-500/20 rounded-full h-2 mt-3">
                  <div className="bg-gradient-to-r from-purple-500 to-pink-500 h-2 rounded-full" style={{ width: '100%' }}></div>
                </div>
              </div>
            </Card>

            <div className="flex space-x-3">
              <Button
                onClick={() => setCurrentStep('beat')}
                variant="outline"
                className="flex-1 border-white/20 text-white rounded-xl"
              >
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back
              </Button>
              <Button
                onClick={() => setCurrentStep('platforms')}
                className="flex-1 bg-gradient-to-r from-purple-500 to-pink-500 rounded-xl"
              >
                Choose Platforms
                <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            </div>
          </div>
        );

      case 'platforms':
        return (
          <div className="space-y-6">
            <div className="text-center">
              <h3 className="text-white font-bold mb-2">Release Platforms</h3>
              <p className="text-purple-200 text-sm">Where do you want to release your track?</p>
            </div>

            <div className="space-y-3">
              {/* Rpotify */}
              <Card 
                className={`p-4 cursor-pointer transition-all border ${
                  trackData.platforms.rpotify 
                    ? 'bg-green-500/20 border-green-500/30' 
                    : 'bg-white/10 border-white/20 hover:bg-white/20'
                }`}
                onClick={() => setTrackData(prev => ({
                  ...prev,
                  platforms: { ...prev.platforms, rpotify: !prev.platforms.rpotify }
                }))}
              >
                <div className="flex items-center space-x-3">
                  <div className="w-12 h-12 bg-green-500/20 rounded-xl flex items-center justify-center">
                    <Music className="w-6 h-6 text-green-400" />
                  </div>
                  <div className="flex-1">
                    <h4 className="text-white font-medium">📱 Rpotify (Spotify)</h4>
                    <p className="text-green-200 text-sm">Main streaming income • $0.30 per stream</p>
                    <p className="text-green-300 text-xs">Boosts: Streams + Fans + Money</p>
                  </div>
                  {trackData.platforms.rpotify && <CheckCircle className="w-5 h-5 text-green-400" />}
                </div>
              </Card>

              {/* RapTube */}
              <Card 
                className={`p-4 cursor-pointer transition-all border ${
                  trackData.platforms.raptube 
                    ? 'bg-red-500/20 border-red-500/30' 
                    : 'bg-white/10 border-white/20 hover:bg-white/20'
                }`}
                onClick={() => setTrackData(prev => ({
                  ...prev,
                  platforms: { ...prev.platforms, raptube: !prev.platforms.raptube }
                }))}
              >
                <div className="flex items-center space-x-3">
                  <div className="w-12 h-12 bg-red-500/20 rounded-xl flex items-center justify-center">
                    <Play className="w-6 h-6 text-red-400" />
                  </div>
                  <div className="flex-1">
                    <h4 className="text-white font-medium">📺 RapTube (YouTube)</h4>
                    <p className="text-red-200 text-sm">Music video platform • $0.15 per view</p>
                    <p className="text-red-300 text-xs">Boosts: Views + Fame + Ad Revenue</p>
                  </div>
                  {trackData.platforms.raptube && <CheckCircle className="w-5 h-5 text-red-400" />}
                </div>
              </Card>

              {/* Riktok */}
              <Card 
                className={`p-4 cursor-pointer transition-all border ${
                  trackData.platforms.riktok 
                    ? 'bg-purple-500/20 border-purple-500/30' 
                    : 'bg-white/10 border-white/20 hover:bg-white/20'
                }`}
                onClick={() => setTrackData(prev => ({
                  ...prev,
                  platforms: { ...prev.platforms, riktok: !prev.platforms.riktok }
                }))}
              >
                <div className="flex items-center space-x-3">
                  <div className="w-12 h-12 bg-purple-500/20 rounded-xl flex items-center justify-center">
                    <TrendingUp className="w-6 h-6 text-purple-400" />
                  </div>
                  <div className="flex-1">
                    <h4 className="text-white font-medium">🎵 Riktok (TikTok)</h4>
                    <p className="text-purple-200 text-sm">Viral potential • Huge fan growth</p>
                    <p className="text-purple-300 text-xs">Chance of viral trend = Massive boost</p>
                  </div>
                  {trackData.platforms.riktok && <CheckCircle className="w-5 h-5 text-purple-400" />}
                </div>
              </Card>
            </div>

            <Card className="bg-blue-500/20 border-blue-500/30 p-4">
              <h4 className="text-blue-200 font-medium mb-2">💡 Strategy Tip</h4>
              <p className="text-blue-300 text-sm">
                More platforms = Higher hype but costs more energy and money. 
                Choose wisely based on your current resources!
              </p>
            </Card>

            <div className="flex space-x-3">
              <Button
                onClick={() => setCurrentStep('record')}
                variant="outline"
                className="flex-1 border-white/20 text-white rounded-xl"
              >
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back
              </Button>
              <Button
                onClick={() => setCurrentStep('preview')}
                disabled={!Object.values(trackData.platforms).some(Boolean)}
                className="flex-1 bg-gradient-to-r from-purple-500 to-pink-500 rounded-xl disabled:opacity-50"
              >
                Preview Release
                <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            </div>
          </div>
        );

      case 'preview':
        const canAfford = gameState.energy >= trackData.energyCost && gameState.money >= trackData.moneyCost;
        const selectedPlatforms = Object.entries(trackData.platforms).filter(([_, enabled]) => enabled);
        
        return (
          <div className="space-y-6">
            <div className="text-center">
              <h3 className="text-white font-bold mb-2">Release Preview</h3>
              <p className="text-purple-200 text-sm">Ready to drop your track?</p>
            </div>

            <Card className="bg-white/10 border-white/20 p-4">
              <h4 className="text-white font-medium mb-3">Track Details:</h4>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-purple-200">Title:</span>
                  <span className="text-white">"{trackData.title}"</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-purple-200">Genre:</span>
                  <span className="text-white">{genres.find(g => g.id === trackData.genre)?.name}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-purple-200">Beat:</span>
                  <span className="text-white">{beats.find(b => b.id === trackData.beat)?.name}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-purple-200">Platforms:</span>
                  <span className="text-white">{selectedPlatforms.length}</span>
                </div>
              </div>
            </Card>

            <Card className="bg-gradient-to-r from-purple-500/20 to-pink-500/20 border-purple-500/30 p-4">
              <h4 className="text-white font-medium mb-3">Success Prediction:</h4>
              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-purple-200">Estimated Quality</span>
                  <Badge className="bg-purple-500/20 text-purple-300">
                    {Math.round(trackData.estimatedSuccess)}%
                  </Badge>
                </div>
                <div className="w-full bg-purple-500/20 rounded-full h-2">
                  <div 
                    className="bg-gradient-to-r from-purple-500 to-pink-500 h-2 rounded-full transition-all duration-1000" 
                    style={{ width: `${Math.min(100, trackData.estimatedSuccess)}%` }}
                  ></div>
                </div>
                <p className="text-purple-300 text-xs">
                  {trackData.estimatedSuccess > 80 ? "🔥 Potential Hit!" : 
                   trackData.estimatedSuccess > 60 ? "⭐ Good Success Chance" : 
                   trackData.estimatedSuccess > 40 ? "📈 Moderate Success" : "🎲 Risky Release"}
                </p>
              </div>
            </Card>

            <Card className="bg-white/10 border-white/20 p-4">
              <h4 className="text-white font-medium mb-3">Costs:</h4>
              <div className="space-y-2">
                <div className="flex justify-between items-center">
                  <span className="text-purple-200 flex items-center">
                    <Zap className="w-4 h-4 mr-1" />
                    Energy Cost
                  </span>
                  <span className={gameState.energy >= trackData.energyCost ? "text-green-300" : "text-red-300"}>
                    {trackData.energyCost}
                  </span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-purple-200 flex items-center">
                    <DollarSign className="w-4 h-4 mr-1" />
                    Money Cost
                  </span>
                  <span className={gameState.money >= trackData.moneyCost ? "text-green-300" : "text-red-300"}>
                    ${trackData.moneyCost.toLocaleString()}
                  </span>
                </div>
              </div>
            </Card>

            {!canAfford && (
              <Card className="bg-red-500/20 border-red-500/30 p-4">
                <p className="text-red-300 text-sm text-center">
                  ⚠️ Insufficient resources! You need more energy or money.
                </p>
              </Card>
            )}

            <div className="flex space-x-3">
              <Button
                onClick={() => setCurrentStep('platforms')}
                variant="outline"
                className="flex-1 border-white/20 text-white rounded-xl"
              >
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back
              </Button>
              <Button
                onClick={createTrack}
                disabled={!canAfford}
                className="flex-1 bg-gradient-to-r from-purple-500 to-pink-500 rounded-xl disabled:opacity-50"
              >
                🚀 Release Track
              </Button>
            </div>
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <div className="max-w-md mx-auto">
      <motion.div
        key={currentStep}
        initial={{ opacity: 0, x: 20 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ duration: 0.3 }}
      >
        {renderStepContent()}
      </motion.div>
    </div>
  );
}