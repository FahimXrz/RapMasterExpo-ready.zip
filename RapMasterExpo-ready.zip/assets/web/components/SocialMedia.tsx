import React from 'react';
import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { GameState } from '../App';
import { Music, Play, Users, TrendingUp, Heart, Eye, Headphones, Zap } from 'lucide-react';

interface SocialMediaProps {
  gameState: GameState;
}

export function SocialMedia({ gameState }: SocialMediaProps) {
  const totalStreams = gameState.tracks.reduce((sum, track) => 
    sum + track.platforms.rpotify.streams, 0
  );
  const totalViews = gameState.tracks.reduce((sum, track) => 
    sum + track.platforms.raptube.views + track.platforms.riktok.views, 0
  );
  const totalLikes = gameState.tracks.reduce((sum, track) => sum + track.likes, 0);

  const getTrackStatus = (track: any) => {
    const trackAge = gameState.week - track.week;
    const isViral = track.platforms.riktok.enabled && track.platforms.riktok.viral;
    
    if (isViral) return { text: '🔥 VIRAL', color: 'bg-red-500/20 text-red-300' };
    if (trackAge <= 2) return { text: '🆕 NEW', color: 'bg-green-500/20 text-green-300' };
    if (trackAge <= 4) return { text: '📈 TRENDING', color: 'bg-blue-500/20 text-blue-300' };
    if (trackAge <= 8) return { text: '⭐ CLASSIC', color: 'bg-purple-500/20 text-purple-300' };
    return { text: '📉 LEGACY', color: 'bg-gray-500/20 text-gray-300' };
  };

  return (
    <div className="space-y-6 max-w-md mx-auto">
      {/* Header Stats */}
      <div className="grid grid-cols-3 gap-3">
        <Card className="bg-green-500/20 border-green-500/30 p-3 text-center">
          <Headphones className="w-5 h-5 text-green-400 mx-auto mb-1" />
          <p className="text-green-200 text-xs">Total Streams</p>
          <p className="text-white font-bold text-sm">{totalStreams.toLocaleString()}</p>
        </Card>
        <Card className="bg-red-500/20 border-red-500/30 p-3 text-center">
          <Eye className="w-5 h-5 text-red-400 mx-auto mb-1" />
          <p className="text-red-200 text-xs">Total Views</p>
          <p className="text-white font-bold text-sm">{totalViews.toLocaleString()}</p>
        </Card>
        <Card className="bg-pink-500/20 border-pink-500/30 p-3 text-center">
          <Heart className="w-5 h-5 text-pink-400 mx-auto mb-1" />
          <p className="text-pink-200 text-xs">Total Likes</p>
          <p className="text-white font-bold text-sm">{totalLikes.toLocaleString()}</p>
        </Card>
      </div>

      {/* Platform Overview */}
      <Card className="bg-white/10 border-white/20 p-4">
        <h3 className="text-white font-bold mb-3">Platform Performance</h3>
        <div className="space-y-3">
          <div className="flex justify-between items-center">
            <span className="text-green-300 flex items-center">
              <Music className="w-4 h-4 mr-2" />
              📱 Rpotify
            </span>
            <span className="text-white">{totalStreams.toLocaleString()} streams</span>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-red-300 flex items-center">
              <Play className="w-4 h-4 mr-2" />
              📺 RapTube
            </span>
            <span className="text-white">
              {gameState.tracks.reduce((sum, track) => sum + track.platforms.raptube.views, 0).toLocaleString()} views
            </span>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-purple-300 flex items-center">
              <TrendingUp className="w-4 h-4 mr-2" />
              🎵 Riktok
            </span>
            <span className="text-white">
              {gameState.tracks.reduce((sum, track) => sum + track.platforms.riktok.views, 0).toLocaleString()} views
            </span>
          </div>
        </div>
      </Card>

      {/* Track List */}
      <div className="space-y-3">
        <h3 className="text-white font-bold">Your Tracks</h3>
        {gameState.tracks.length === 0 ? (
          <Card className="bg-white/10 border-white/20 p-6 text-center">
            <Music className="w-12 h-12 text-purple-400 mx-auto mb-3 opacity-50" />
            <p className="text-purple-200">No tracks released yet</p>
            <p className="text-purple-300 text-sm mt-1">Go to Create tab to make your first track!</p>
          </Card>
        ) : (
          gameState.tracks.map((track) => {
            const status = getTrackStatus(track);
            const trackAge = gameState.week - track.week;
            
            return (
              <Card key={track.id} className="bg-white/10 border-white/20 p-4">
                <div className="flex justify-between items-start mb-3">
                  <div className="flex-1">
                    <h4 className="text-white font-medium">{track.title}</h4>
                    <p className="text-purple-200 text-sm">{track.genre} • Week {track.week}</p>
                  </div>
                  <Badge className={status.color}>{status.text}</Badge>
                </div>

                {/* Platform Stats */}
                <div className="space-y-2 mb-3">
                  {track.platforms.rpotify.enabled && (
                    <div className="flex justify-between items-center text-sm">
                      <span className="text-green-300">📱 {track.platforms.rpotify.title}</span>
                      <span className="text-white">{track.platforms.rpotify.streams.toLocaleString()}</span>
                    </div>
                  )}
                  {track.platforms.raptube.enabled && (
                    <div className="flex justify-between items-center text-sm">
                      <span className="text-red-300">📺 {track.platforms.raptube.title}</span>
                      <span className="text-white">{track.platforms.raptube.views.toLocaleString()}</span>
                    </div>
                  )}
                  {track.platforms.riktok.enabled && (
                    <div className="flex justify-between items-center text-sm">
                      <span className="text-purple-300 flex items-center">
                        🎵 Riktok Snippet
                        {track.platforms.riktok.viral && <Zap className="w-3 h-3 ml-1 text-yellow-400" />}
                      </span>
                      <span className="text-white">{track.platforms.riktok.views.toLocaleString()}</span>
                    </div>
                  )}
                </div>

                {/* Track Lifecycle Info */}
                <div className="flex justify-between items-center text-xs">
                  <span className="text-purple-300">
                    {trackAge === 0 ? 'Just Released!' : `${trackAge} weeks old`}
                  </span>
                  <span className="text-purple-300">
                    Quality: {Math.round(track.quality)}%
                  </span>
                </div>
                
                {track.platforms.riktok.viral && (
                  <div className="mt-2 p-2 bg-yellow-500/20 border border-yellow-500/30 rounded-lg">
                    <p className="text-yellow-300 text-xs text-center">
                      🔥 VIRAL ON RIKTOK! Massive fan boost incoming!
                    </p>
                  </div>
                )}
              </Card>
            );
          })
        )}
      </div>

      {gameState.tracks.length > 0 && (
        <Card className="bg-gradient-to-r from-purple-500/20 to-pink-500/20 border-purple-500/30 p-4">
          <h4 className="text-purple-200 font-medium mb-2">📊 Career Overview</h4>
          <div className="grid grid-cols-2 gap-3 text-sm">
            <div>
              <p className="text-purple-300">Total Revenue</p>
              <p className="text-white font-bold">
                ${((totalStreams * 0.30) + (totalViews * 0.15)).toLocaleString()}
              </p>
            </div>
            <div>
              <p className="text-purple-300">Viral Moments</p>
              <p className="text-white font-bold">
                {gameState.tracks.filter(track => track.platforms.riktok.viral).length}
              </p>
            </div>
            <div>
              <p className="text-purple-300">Platforms Used</p>
              <p className="text-white font-bold">
                {Math.max(...gameState.tracks.map(track => 
                  Object.values(track.platforms).filter(p => p.enabled).length
                ))}
              </p>
            </div>
            <div>
              <p className="text-purple-300">Best Track</p>
              <p className="text-white font-bold text-xs">
                {gameState.tracks.length > 0 
                  ? gameState.tracks.reduce((best, track) => 
                      track.quality > best.quality ? track : best
                    ).title.substring(0, 10) + '...'
                  : 'None'
                }
              </p>
            </div>
          </div>
        </Card>
      )}
    </div>
  );
}