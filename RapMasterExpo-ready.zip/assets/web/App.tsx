import React, { useState, useEffect } from 'react';
import { SplashScreen } from './components/SplashScreen';
import { CharacterCreation } from './components/CharacterCreation';
import { GameScreen } from './components/GameScreen';
import { Credits } from './components/Credits';
import { LockedFeatureDialog } from './components/LockedFeatureDialog';

export interface Character {
  name: string;
  gender: 'male' | 'female';
  age: number;
  hairstyle: number;
  skin: number;
}

export interface Skills {
  rap: number;
  flow: number;
  charisma: number;
}

export interface Track {
  id: string;
  title: string;
  genre: string;
  beat: string;
  week: number;
  platforms: {
    rpotify: { enabled: boolean; streams: number; title: string };
    raptube: { enabled: boolean; views: number; title: string };
    riktok: { enabled: boolean; views: number; viral: boolean };
  };
  likes: number;
  quality: number;
  viralFactor: number;
  peakWeek: number;
  isDeclined: boolean;
}

export interface GameState {
  character: Character | null;
  skills: Skills;
  energy: number;
  money: number;
  fame: number;
  fans: number;
  week: number;
  tracks: Track[];
  totalStreams: number;
  totalViews: number;
  studioLevel: number; // 1 = Basic, 2 = Premium, 3 = Pro
}

type Screen = 'splash' | 'character' | 'game' | 'credits';

export default function App() {
  const [currentScreen, setCurrentScreen] = useState<Screen>('splash');
  const [showLockedDialog, setShowLockedDialog] = useState(false);
  const [gameState, setGameState] = useState<GameState>({
    character: null,
    skills: { rap: 1, flow: 1, charisma: 1 },
    energy: 100,
    money: 0,
    fame: 0,
    fans: 0,
    week: 1,
    tracks: [],
    totalStreams: 0,
    totalViews: 0,
    studioLevel: 1,
  });

  useEffect(() => {
    const timer = setTimeout(() => {
      setCurrentScreen('character');
    }, 3000);
    return () => clearTimeout(timer);
  }, []);

  useEffect(() => {
    const handleShowCredits = () => {
      setCurrentScreen('credits');
    };
    
    window.addEventListener('showCredits', handleShowCredits);
    return () => {
      window.removeEventListener('showCredits', handleShowCredits);
    };
  }, []);

  const handleCharacterCreated = (character: Character) => {
    setGameState(prev => ({ ...prev, character }));
    setCurrentScreen('game');
  };

  const handleBackToGame = () => {
    setCurrentScreen('game');
  };

  const handleLockedFeature = () => {
    setShowLockedDialog(true);
  };

  const renderScreen = () => {
    switch (currentScreen) {
      case 'splash':
        return <SplashScreen />;
      case 'character':
        return <CharacterCreation onCharacterCreated={handleCharacterCreated} />;
      case 'game':
        return (
          <GameScreen
            gameState={gameState}
            setGameState={setGameState}
            onLockedFeature={handleLockedFeature}
          />
        );
      case 'credits':
        return <Credits onBack={handleBackToGame} />;
      default:
        return <SplashScreen />;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900 text-white overflow-hidden">
      {renderScreen()}
      <LockedFeatureDialog 
        isOpen={showLockedDialog} 
        onClose={() => setShowLockedDialog(false)} 
      />
    </div>
  );
}