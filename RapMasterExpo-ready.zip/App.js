import React from "react";
import { WebView } from "react-native-webview";

export default function App() {
  return (
    <WebView
      originWhitelist={['*']}
      source={require("./assets/web/index.html")}
      style={{ flex: 1 }}
    />
  );
}
